# OpenPAV

Code for surrogate car-following behavior modeling and scenario-based vehicle
evaluation. The pipeline trains an LSTM acceleration model, calibrates its
residual distribution, evaluates an independent test set, runs Monte Carlo
simulation, and estimates stationary TTC-block probabilities with Markov sampling.

## Contents

| Path | Purpose |
| --- | --- |
| `behavior_modeling/` | Trajectory splitting, training, calibration and independent testing |
| `evaluation/` | Monte Carlo metrics, Markov sampling, stationary-state solver and IDM baseline |
| `run_all.py` | One-vehicle pipeline |
| `run_batch.sh` | Sequential experiments for eight learned vehicle models |
| `experiments/` | Vehicle/file mapping and numerical result export |
| `examples/` | Synthetic input generator |
| `tests/` | Split isolation, test-metric and pipeline dispatch checks |

This distribution contains no plotting code, raw research data, trained weights,
local experiment outputs, review correspondence or server scheduling scripts.
The unused NDE and plotting imports have been removed; evaluation does not
require NDE array files. Dataset paths are supplied through command-line options.

## Installation

Use Python 3.11. Open a terminal in this directory, then run:

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
```

On Windows, activate with `.venv\Scripts\activate`. The batch shell script
requires Bash; individual Python commands can be used without Bash.

Training and learned-model inference select CUDA when PyTorch detects an
available GPU, otherwise CPU. Monte Carlo and Markov sampling use CPU code but
call the learned predictor, which can use the GPU. On Linux/macOS, prefix a
command with `CUDA_VISIBLE_DEVICES=""` to run entirely on CPU, or
`CUDA_VISIBLE_DEVICES=0` to select a GPU. There is no cluster or queue dependency.

## Quick execution check

The synthetic example checks the software pipeline; it does not reproduce
vehicle performance. Run these commands from the project root:

```bash
python examples/make_demo_data.py
python run_all.py --data_csv data/demo/trajectories.csv --fav_id 0 --train_epochs 2 --mc_iterations 100 --mc_interval 100 --skip_markov --results_root results_demo
python -m unittest discover -s tests -v
```

This trains, calibrates, independently tests and computes Monte Carlo metrics
with small workloads. Markov evaluation needs a much larger state sample for
meaningful estimates. For a data-free IDM experiment:

```bash
python run_all.py --benchmark_model idm --mc_iterations 1000000 --results_root results_idm
```

## Research experiments

Prepare the processed CSV inputs described in [data/README.md](data/README.md).
For a single vehicle:

```bash
python run_all.py --data_csv data/OpenACC/step3_Casale.csv --fav_id 0 --results_root results
```

For all eight vehicles, including training, calibration, independent testing,
all Monte Carlo metrics and Markov evaluation:

```bash
bash run_batch.sh --results_root results
python experiments/summarize_results.py --results_root results
```

The batch runs vehicles sequentially. Extra options are forwarded to each run.
See [experiments/README.md](experiments/README.md) for settings and output semantics.
The default simulator uses one observation per prediction (`--seq_len 1`);
longer sequences are supported by the training loader but the simulator does
not maintain a matching history buffer.

The runner reuses existing output files. Use a fresh `--results_root` or
`--run_name` when changing data or settings. Existing-file checks do not verify
that the previous experiment used the same configuration or finished every
Markov block. `--skip_train`, `--skip_mc` and `--skip_markov` allow individual
stages to be reused explicitly.

## Training and test protocol

The generic split assigns complete trajectories to training, validation,
calibration and testing with requested proportions 60/15/10/15%. Integer group
counts and unequal trajectory lengths mean sample proportions can differ.
Prediction windows are generated only after the split, within each group;
the target is the acceleration in the row immediately following the window.

For Vanderbilt, the shorter of its two trajectories is held out in full for
testing. The longer trajectory is divided chronologically into 70/15/15%
training/validation/calibration blocks by row count. The first 10 seconds after
each internal boundary are excluded. These development blocks come from one
trajectory and should not be interpreted as independent collection sessions.
The runner chooses this strategy for a CSV whose parent folder is `Vanderbilt`;
use `--split_strategy vanderbilt` explicitly for another directory name.

The best checkpoint is selected by validation MAE. Bias, scale and power-law
parameters are fitted only on calibration data. The frozen model and calibration
are evaluated on the independent test subset. Saved test metrics include raw
and calibrated MAE/RMSE and empirical coverage at nominal 50/90/95/99% levels.
Coverage refers to the continuous residual model before the simulation's action
truncation and discretization; it is measured, not guaranteed.

## License

The code is distributed under the [MIT License](LICENSE). External datasets
are not included and retain their respective terms.
