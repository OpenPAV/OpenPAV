"""Run on CPU: python -m unittest discover -s tests."""
import sys
import tempfile
import unittest
from unittest.mock import patch
from pathlib import Path

import numpy as np
import pandas as pd
import torch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "behavior_modeling"))
from read_data import load_fav_splits
from train import evaluate_model
import run_all


class SplitTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)

    def tearDown(self):
        self.temp.cleanup()

    def write_data(self, name, lengths):
        rows = []
        for trajectory, length in enumerate(lengths):
            for t in range(length):
                value = trajectory * 10000 + t
                rows.append(dict(Trajectory_ID=trajectory, Time_Index=t * 0.1,
                                 ID_FAV=0, Spatial_Gap=value, Speed_LV=10,
                                 Speed_FAV=9, Acc_FAV=value))
        path = self.root / name
        pd.DataFrame(rows).to_csv(path, index=False)
        return str(path)

    def test_group_isolation_and_next_frame_windows(self):
        # The two files deliberately reuse trajectory IDs.
        self.write_data('a.csv', [20] * 12)
        self.write_data('b.csv', [20] * 12)
        datasets, manifest = load_fav_splits(data_dir=str(self.root), seq_len=3)
        _, repeat = load_fav_splits(data_dir=str(self.root), seq_len=3)
        self.assertEqual(manifest, repeat)
        seen = set()
        for name, split in manifest['splits'].items():
            ids = {g['id'] for g in split['groups']}
            self.assertTrue(seen.isdisjoint(ids))
            seen.update(ids)
            X, y = datasets[name].tensors
            np.testing.assert_array_equal(y[:, 0], X[:, -1, 0] + 1)
            self.assertTrue(torch.all(X[:, 1:, 0] - X[:, :-1, 0] == 1))
        self.assertEqual(len(seen), 24)

    def test_vanderbilt_test_is_untouched_and_internal_gaps(self):
        path = self.write_data('vanderbilt.csv', [1200, 500])
        datasets, manifest = load_fav_splits(csv_file=path, seq_len=3,
                                            split_strategy='vanderbilt', gap_seconds=10)
        splits = manifest['splits']
        self.assertEqual(len(datasets['test']), 497)
        self.assertTrue(splits['test']['groups'][0]['id'].endswith('::1'))
        for left, right in [('train', 'validation'), ('validation', 'calibration')]:
            a, b = splits[left]['groups'][0], splits[right]['groups'][0]
            self.assertEqual(a['id'], b['id'])
            self.assertGreater(b['time_start'] - a['time_end'], 10)
        # All raw input AND target times used by each block stay inside that block.
        for name, dataset in datasets.items():
            X, y = dataset.tensors
            np.testing.assert_array_equal(y[:, 0], X[:, -1, 0] + 1)
            self.assertTrue(torch.all(X[:, 1:, 0] - X[:, :-1, 0] == 1))

    def test_metrics_weight_samples_and_apply_frozen_calibration(self):
        class ConstantModel(torch.nn.Module):
            def forward(self, x):
                return torch.zeros(len(x), 1, 1), torch.ones(len(x), 1, 1)
        data = torch.utils.data.TensorDataset(torch.zeros(3, 1, 3), torch.tensor([[0.], [0.], [3.]]))
        loader = torch.utils.data.DataLoader(data, batch_size=2)
        metrics = evaluate_model(ConstantModel(), loader, torch.device('cpu'),
                                 {'bias': 1, 'sigma_scale': 1, 'a': 1, 'k': -1})
        self.assertAlmostEqual(metrics['mae'], 1)
        self.assertAlmostEqual(metrics['rmse'], np.sqrt(3))
        self.assertAlmostEqual(metrics['calibrated_mae'], 4 / 3)
        self.assertAlmostEqual(metrics['continuous_power_law_coverage']['0.5'], 2 / 3)

    def test_pipeline_dispatches_training_all_metrics_and_markov(self):
        calls = []
        source = self.root / 'OpenACC' / 'step3_Casale.csv'
        source.parent.mkdir()
        source.touch()
        def record(cmd, env=None):
            calls.append(cmd)
            if cmd[1] == 'evaluation/MonteCarlo.py':
                result_dir = Path(cmd[cmd.index('--results_dir') + 1])
                (result_dir / 'states_record.json').write_text('{}')
        args = ['run_all.py', '--data_csv', str(source), '--fav_id', '0',
                '--results_root', str(self.root / 'results')]
        with patch.object(sys, 'argv', args), patch.object(run_all, 'run_cmd', side_effect=record):
            run_all.main()
        self.assertEqual([c[1] for c in calls], ['behavior_modeling/train.py',
            'evaluation/MonteCarlo.py', 'evaluation/Markov.py', 'evaluation/markov_steady_state.py'])
        self.assertIn('OpenACC_Casale_FAV0', calls[0][-1])
        self.assertEqual(calls[0][calls[0].index('--split_strategy') + 1], 'trajectory')


if __name__ == '__main__':
    unittest.main()
