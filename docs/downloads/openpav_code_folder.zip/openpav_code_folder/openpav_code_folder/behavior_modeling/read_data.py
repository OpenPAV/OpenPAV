from pathlib import Path
from typing import List

import numpy as np
import pandas as pd
import torch
from torch.utils.data import TensorDataset


# Input features per timestep (no acceleration)
INPUT_COLS: List[str] = ["Spatial_Gap", "Speed_LV", "Speed_FAV"]
TARGET_COL = "Acc_FAV"
ID_COL = "ID_FAV"
TIME_COL = "Time_Index"
TRAJ_COL = "Trajectory_ID"


def _read_trajectories(data_dir, fav_id, csv_file, seq_len):
    if csv_file:
        csv_files = [Path(csv_file)]
    else:
        if data_dir is None:
            # Default to project_root/data relative to this file.
            data_dir = Path(__file__).resolve().parents[1] / "data"
        else:
            data_dir = Path(data_dir)
        csv_files = sorted(data_dir.glob("*.csv"))
    trajectories = []
    for csv_path in csv_files:
        df = pd.read_csv(
            csv_path,
            usecols=[TRAJ_COL, TIME_COL, ID_COL, *INPUT_COLS, TARGET_COL],
        )
        df = df[df[ID_COL] == fav_id]
        if df.empty:
            continue

        for trajectory_id, group in df.groupby(TRAJ_COL):
            group = group.sort_values(TIME_COL)
            if len(group) > seq_len:
                trajectories.append((f"{csv_path.name}::{trajectory_id}", group))
    return trajectories


def _make_dataset(trajectories, seq_len):
    X_sequences, y_targets = [], []
    for _, group in trajectories:
        inputs = group[INPUT_COLS].to_numpy(dtype=np.float32)
        targets = group[TARGET_COL].to_numpy(dtype=np.float32)
        for start in range(len(inputs) - seq_len):
            end = start + seq_len
            X_sequences.append(inputs[start:end])
            y_targets.append(targets[end])

    if not X_sequences:
        # Return empty tensors to keep the signature consistent.
        return TensorDataset(
            torch.empty(0, seq_len, len(INPUT_COLS)),
            torch.empty(0, 1),
        )

    X = torch.from_numpy(np.stack(X_sequences)).float()
    y = torch.from_numpy(np.array(y_targets, dtype=np.float32)).unsqueeze(-1)
    return TensorDataset(X, y)


def load_fav_sequences(data_dir=None, fav_id=1, seq_len=10, csv_file=None):
    """Build next-frame acceleration samples within each complete trajectory."""
    return _make_dataset(_read_trajectories(data_dir, fav_id, csv_file, seq_len), seq_len)


def load_fav_splits(data_dir=None, fav_id=0, seq_len=1, csv_file=None,
                    train_ratio=0.6, val_ratio=0.15, calibration_ratio=0.1,
                    seed=42, split_strategy="trajectory", gap_seconds=10.0):
    """Split raw trajectories before generating windows; return datasets and manifest.

    Vanderbilt: hold out the shorter trajectory; split the longer one 70/15/15
    in time, excluding gap_seconds after each internal boundary. This gap is
    configurable, not a claim that temporal blocks are independent sessions.
    """
    trajectories = _read_trajectories(data_dir, fav_id, csv_file, seq_len)
    parts = {name: [] for name in ("train", "validation", "calibration", "test")}
    if split_strategy == "vanderbilt":
        if len(trajectories) != 2:
            raise ValueError("Vanderbilt split expects exactly two trajectories.")
        if gap_seconds < 0:
            raise ValueError("gap_seconds must be nonnegative.")
        development, test = sorted(trajectories, key=lambda item: len(item[1]), reverse=True)
        key, frame = development
        b1, b2 = int(len(frame) * 0.7), int(len(frame) * 0.85)
        parts["train"] = [(key, frame.iloc[:b1])]
        for name, start, stop in (("validation", b1, b2), ("calibration", b2, len(frame))):
            block = frame.iloc[start:stop]
            boundary_time = frame.iloc[start - 1][TIME_COL]
            block = block[block[TIME_COL] > boundary_time + gap_seconds]
            parts[name] = [(key, block)]
        parts["test"] = [test]
        ratios = {"development_train": 0.7, "development_validation": 0.15,
                  "development_calibration": 0.15, "test": "shorter complete trajectory"}
    elif split_strategy == "trajectory":
        test_ratio = 1 - train_ratio - val_ratio - calibration_ratio
        if min(train_ratio, val_ratio, calibration_ratio, test_ratio) <= 0:
            raise ValueError("All four split ratios must be positive and sum to one.")
        n = len(trajectories)
        n_val, n_cal, n_test = [max(1, round(n * r)) for r in (val_ratio, calibration_ratio, test_ratio)]
        n_train = n - n_val - n_cal - n_test
        if n_train < 1:
            raise ValueError("Not enough trajectories for the requested four-way split.")
        order = np.random.default_rng(seed).permutation(n)
        offset = 0
        for name, count in zip(parts, (n_train, n_val, n_cal, n_test)):
            parts[name] = [trajectories[i] for i in order[offset:offset + count]]
            offset += count
        ratios = dict(zip(parts, (train_ratio, val_ratio, calibration_ratio, test_ratio)))
    else:
        raise ValueError(f"Unknown split strategy: {split_strategy}")

    datasets = {name: _make_dataset(groups, seq_len) for name, groups in parts.items()}
    if any(len(dataset) == 0 for dataset in datasets.values()):
        raise ValueError("A split has no prediction samples; adjust groups or temporal gap.")
    manifest = {"strategy": split_strategy, "seed": seed, "fav_id": fav_id,
                "seq_len": seq_len, "requested_ratios": ratios,
                "gap_seconds": gap_seconds if split_strategy == "vanderbilt" else None,
                "splits": {}}
    for name, groups in parts.items():
        manifest["splits"][name] = {
            "samples": len(datasets[name]),
            "groups": [{"id": key, "rows": len(frame),
                        "time_start": float(frame[TIME_COL].iloc[0]),
                        "time_end": float(frame[TIME_COL].iloc[-1])}
                       for key, frame in groups],
        }
    return datasets, manifest


__all__ = ["load_fav_sequences", "load_fav_splits"]
