import torch
import torch.optim as optim
import logging
import os
import torch.optim.lr_scheduler as LR_scheduler
import argparse
from pathlib import Path
import json
import numpy as np
import random
import time
from sklearn import linear_model as regression
from tqdm import tqdm
from read_data import load_fav_splits
from model import ego_acc_LSTM_dist
from criterion import dist_loss


# Parameters
def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--data_dir', type=str, default='./data/MicroSimACC', help='Directory containing csv files')
    parser.add_argument('--data_csv', type=str, default=None, help='Single CSV file to use')
    parser.add_argument('--fav_id', type=int, default=0, help='Target FAV ID')
    parser.add_argument('--seq_len', type=int, default=1, help='Sequence length for LSTM input')
    parser.add_argument('--train_ratio', type=float, default=0.6, help='Fraction of trajectory groups for training')
    parser.add_argument('--val_ratio', type=float, default=0.15)
    parser.add_argument('--calibration_ratio', type=float, default=0.1)
    parser.add_argument('--split_strategy', choices=['trajectory', 'vanderbilt'], default='trajectory')
    parser.add_argument('--gap_seconds', type=float, default=10.0, help='Vanderbilt internal time-block gap')
    parser.add_argument('--seed', type=int, default=42)
    parser.add_argument('--batch_size', type=int, default=128, help='Batch size')
    parser.add_argument('--num_epochs', type=int, default=100, help='Training epochs')
    parser.add_argument('--result_dir', type=str, default=None, help='Output directory for model/checkpoints')
    
    return parser.parse_args()


def scaling_law(acc, K=20, a_min=0.1, a_max=1000.0):
    acc = np.array(acc)
    mean = np.mean(acc)
    std = np.std(acc)

    prob = []
    n = np.linspace(0.01, K, 300)
    for i in tqdm(n, desc="Calculating probability"):
        prob.append(np.sum((acc > mean + i * std) | (acc < mean - i * std)) / len(acc))
        if prob[-1] == 0.0:
            prob = prob[:-1]
            n = n[: len(prob)]
            break
    prob = np.array(prob)
    n = n[prob > 1 / len(acc) * 10]
    prob = prob[prob > 1 / len(acc) * 10]
    n = n[prob < 1.0]
    prob = prob[prob < 1.0]

    D = n * std
    x = np.log(prob)

    best_R2 = 0
    best_a = None
    best_k = None
    for a in np.linspace(a_min, a_max, int((a_max - a_min) * 10)):
        y_tmp = np.log(D / a + 1)
        reg = regression.LinearRegression(fit_intercept=False)
        reg.fit(x.reshape(-1, 1), y_tmp)
        k = reg.coef_[0]
        R2 = reg.score(x.reshape(-1, 1), y_tmp)
        if R2 > best_R2:
            best_R2 = R2
            best_k = k
            best_a = a

    return best_a, best_k, best_R2


def calibrate_distribution(model, data_loader, device, result_dir, logger):
    """Fit distribution parameters using only the dedicated calibration set."""
    if data_loader is None or len(data_loader) == 0:
        logger.info('Calibration skipped: no calibration data.')
        return

    model.eval()
    residuals = []
    sigmas = []
    with torch.no_grad():
        for X_batch, y_batch in data_loader:
            X_batch = X_batch.to(device=device)
            y_batch = y_batch.to(device=device)
            mu, sigma = model(X_batch)
            mu = mu.view(-1)
            sigma = sigma.view(-1)
            y = y_batch.view(-1)
            resid = (y - mu).detach().cpu()
            residuals.append(resid)
            sigmas.append(sigma.detach().cpu())

    if not residuals or not sigmas:
        logger.info('Calibration skipped: empty residuals.')
        return

    residuals = torch.cat(residuals)
    sigmas = torch.cat(sigmas)
    bias = residuals.mean().item()
    mae = residuals.abs().mean().item()
    sigma_mean = sigmas.mean().item()
    sigma_scale = mae / (sigma_mean + 1e-8)

    calib = {
        "bias": bias,
        "mae": mae,
        "sigma_mean": sigma_mean,
        "sigma_scale": sigma_scale,
    }

    residuals_np = residuals.detach().cpu().numpy()
    if np.std(residuals_np) > 1e-8:
        best_a, best_k, best_R2 = scaling_law(residuals_np)
        calib["a"] = float(best_a)
        calib["k"] = float(best_k)
        calib["scaling_law_R2"] = float(best_R2)
        logger.info(f"Scaling law fit: a={best_a}, k={best_k}, R2={best_R2}")
    else:
        logger.info("Scaling law fit skipped: residual std too small.")
    with open(os.path.join(result_dir, 'calibration.json'), 'w') as f:
        json.dump(calib, f, indent=2)
    logger.info(f'Calibration results saved: {calib}')
    return calib


def evaluate_model(model, data_loader, device, calibration=None):
    """Sample-weighted errors; optional coverage of the continuous power-law model.

    Coverage is measured before the simulation's action truncation/discretization.
    No parameters are fitted here.
    """
    model.eval()
    errors, scales = [], []
    with torch.no_grad():
        for X, y in data_loader:
            mu, sigma = model(X.to(device))
            errors.append((y.view(-1) - mu.view(-1).cpu()).numpy())
            scales.append(sigma.view(-1).cpu().numpy())
    residual = np.concatenate(errors).astype(np.float64)
    sigma = np.concatenate(scales).astype(np.float64)
    metrics = {"samples": len(residual), "mae": float(np.abs(residual).mean()),
               "rmse": float(np.sqrt(np.mean(residual ** 2)))}
    if calibration is not None:
        residual = residual - calibration["bias"]
        sigma = sigma * calibration["sigma_scale"]
        metrics["calibrated_mae"] = float(np.abs(residual).mean())
        metrics["calibrated_rmse"] = float(np.sqrt(np.mean(residual ** 2)))
        if "a" in calibration and "k" in calibration:
            metrics["continuous_power_law_coverage"] = {
                str(level): float(np.mean(np.abs(residual) <=
                    calibration["a"] * sigma * ((1 - level) ** calibration["k"] - 1)))
                for level in (0.5, 0.9, 0.95, 0.99)
            }
    return metrics




def main(model_type = 'LSTM'):
    args = parse_args()
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    #log file
    logger = logging.getLogger('')
    logger.handlers.clear()
    root = 'results'
    if args.result_dir:
        result_file = args.result_dir
        os.makedirs(result_file, exist_ok=True)
    else:
        # new log file folder, e.g. results/MicroSimACC_FAV0_seq10
        data_name = Path(args.data_csv).parent.name if args.data_csv else Path(args.data_dir).name
        tag = f'{data_name}_FAV{args.fav_id}_seq{args.seq_len}'
        result_file = os.path.join(root, tag)
        os.makedirs(result_file, exist_ok=True)
    # set the log file path
    filehandler = logging.FileHandler(os.path.join(result_file, 'training.log'))
    streamhandler = logging.StreamHandler()
    logger.setLevel(logging.INFO)
    logger.addHandler(filehandler)
    logger.addHandler(streamhandler)


    # Set hyperparameters
    output_steps = 1
    batch_size = args.batch_size
    hidden_size = 128
    num_layers = 2
    num_epochs = args.num_epochs
    lr = 0.0001
    num_dir = 1
    
    logger.info('*'*50)
    logger.info(f'output_steps: {output_steps}, batch_size: {batch_size}, hidden_size: {hidden_size}, num_layers: {num_layers}, num_epochs: {num_epochs}, lr: {lr}')
    logger.info('*'*50)
    logger.info(f'data_dir: {Path(args.data_dir).name}, fav_id: {args.fav_id}, seq_len: {args.seq_len}, train_ratio: {args.train_ratio}')
    logger.info('*'*50)
    # Load dataset
    data_root = Path(args.data_dir)
    datasets, split_manifest = load_fav_splits(
        data_dir=str(data_root),
        fav_id=args.fav_id,
        seq_len=args.seq_len,
        csv_file=args.data_csv,
        train_ratio=args.train_ratio, val_ratio=args.val_ratio,
        calibration_ratio=args.calibration_ratio, seed=args.seed,
        split_strategy=args.split_strategy, gap_seconds=args.gap_seconds,
    )
    with open(os.path.join(result_file, 'split_manifest.json'), 'w') as f:
        json.dump(split_manifest, f, indent=2)
    loaders = {name: torch.utils.data.DataLoader(dataset, batch_size=batch_size,
                shuffle=(name == 'train')) for name, dataset in datasets.items()}
    train_loader, val_loader = loaders['train'], loaders['validation']
    for name, dataset in datasets.items():
        logger.info(f'{name}: {len(dataset)} sequences')
    
    # Create model, loss function, and optimizer
    num_feature = datasets['train'].tensors[0].shape[-1]
    if model_type == 'LSTM_dist':
        model = ego_acc_LSTM_dist(num_feature = num_feature, hidden_size = hidden_size, num_layers = num_layers, output_size = output_steps, NUMDIR=num_dir)
        criterion = dist_loss()
    else:
        raise NotImplementedError
    model = model.to(device=device)
    
    
    optimizer = optim.Adam(model.parameters(), lr=lr)
    # Set up the learning rate scheduler
    lr_scheduler = LR_scheduler.MultiStepLR(optimizer, milestones=[60,90], gamma=0.1)

    best_mae = 9999

    # Train model
    logger.info('############# Start Training #############')
    training_start = time.perf_counter()
    epoch_times = []
    for epoch in range(num_epochs):
        epoch_start = time.perf_counter()
        model.train()
        # current_lr = optimizer.state_dict()['param_groups'][0]['lr']
        # logger.info(f'############# Starting Epoch {epoch+1} | LR: {current_lr} #############')
        
        train_loss = 0
        #train_loader = tqdm(train_loader, dynamic_ncols=True)
        for X_batch, y_batch in train_loader:
            X_batch = X_batch.to(device=device)
            y_batch = y_batch.to(device=device).view(-1, output_steps, num_dir)

            # Forward pass
            outputs = model(X_batch)
            loss = criterion(outputs, y_batch)

            # Backward and optimize
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            train_loss += loss.item()
        
        # Update learning rate
        lr_scheduler.step()


        if (epoch+1) % 1 == 0:
            logger.info(f'Epoch [{epoch+1}/{num_epochs}], Loss: {train_loss/len(train_loader):.6f}')
        

            MAE = evaluate_model(model, val_loader, device)['mae']
            logger.info(f'Epoch [{epoch+1}/{num_epochs}], validation MAE (Acc_FAV): {MAE:.4f}')
            if MAE < best_mae:
                best_mae = MAE
                torch.save(model.state_dict(), f'{result_file}/best.pth')
        epoch_times.append(time.perf_counter() - epoch_start)
        logger.info(f'Epoch elapsed: {epoch_times[-1]:.3f}s')

    training_seconds = time.perf_counter() - training_start
    model.load_state_dict(torch.load(os.path.join(result_file, 'best.pth'), map_location=device))
    calibration = calibrate_distribution(model, loaders['calibration'], device, result_file, logger)
    test_metrics = evaluate_model(model, loaders['test'], device, calibration)
    with open(os.path.join(result_file, 'test_metrics.json'), 'w') as f:
        json.dump(test_metrics, f, indent=2)
    logger.info(f'Independent test metrics: {test_metrics}')
    with open(os.path.join(result_file, 'training_summary.json'), 'w') as f:
        config = vars(args).copy()
        # Keep source identifiers without embedding machine-specific directory trees.
        for key in ('data_dir', 'data_csv', 'result_dir'):
            if config[key] is not None:
                config[key] = Path(config[key]).name
        json.dump({"config": config, "device": str(device),
                   "device_name": torch.cuda.get_device_name(device) if device.type == 'cuda' else 'CPU',
                   "parameter_count": sum(p.numel() for p in model.parameters()),
                   "training_seconds": training_seconds, "epoch_seconds": epoch_times,
                   "best_validation_mae": best_mae,
                   "post_training_seconds": time.perf_counter() - training_start - training_seconds}, f, indent=2)

    # save the final model
    torch.save(model.state_dict(), f'{result_file}/final.pth')



if __name__ == '__main__':
    main(model_type='LSTM_dist')
