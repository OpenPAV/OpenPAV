"""Create synthetic CSV input for checking the pipeline, not research results."""
import argparse
import csv
import math
import random
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=Path('data/demo/trajectories.csv'))
    args = parser.parse_args()
    rng = random.Random(42)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    columns = ['Trajectory_ID', 'Time_Index', 'ID_FAV', 'Spatial_Gap',
               'Speed_LV', 'Speed_FAV', 'Acc_FAV']
    with args.output.open('w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(columns)
        for trajectory in range(20):
            phase = rng.uniform(0, 2 * math.pi)
            speed = rng.uniform(15, 25)
            for i in range(200):
                t = i * 0.1
                gap = 35 + 5 * math.sin(t / 8 + phase)
                speed_lv = speed + math.sin(t / 6 + phase)
                speed_fav = speed + 0.8 * math.sin(t / 6 + phase - 0.2)
                acceleration = (0.15 * (speed_lv - speed_fav)
                                + 0.02 * (gap - 35) + rng.gauss(0, 0.35))
                writer.writerow([trajectory, t, 0, gap, speed_lv, speed_fav, acceleration])
    print(f'Wrote synthetic demo data to {args.output}')


if __name__ == '__main__':
    main()
