# Experiment settings and numerical outputs

`vehicles.json` records the eight models, processed CSV filenames, follower IDs
and output directory names used by `run_batch.sh`. IDM is a separate baseline.
Real data and stored experiment outputs are not included.

## Main pipeline defaults

| Setting | Value |
| --- | --- |
| LSTM | 3 input features, hidden size 128, 2 layers, sequence length 1 |
| Training | 1,000 epochs, batch size 128, Adam learning rate 0.0001 |
| Learning-rate schedule | Multiply by 0.1 at epochs 60 and 90 |
| Checkpoint selection | Lowest validation MAE |
| Split and training seed | 42 |
| Monte Carlo iterations | 1,000,000, with no burn-in removal |
| Monte Carlo logging interval | 10,000 iterations |
| Simulation timestep | 0.2 s |
| State/action discretization | 0.1 in the corresponding physical units |
| Markov samples per iteration | 500; 5,000 in the first (safest) block |
| Markov relative-change threshold | 0.05 |
| Stationary power iteration | Maximum 10,000 steps; tolerance 1e-12 |

These are `run_all.py` defaults. Standalone `train.py`, `MonteCarlo.py` and
`Markov.py` retain their own defaults; use the main runner for the settings above.
Hyperparameters can be inspected with `python run_all.py --help` and in
`behavior_modeling/train.py` and `evaluation/utils.py`.

## Sampling and stopping

Markov sampling begins with Monte Carlo state records and traverses TTC blocks
from safer to more critical. Each iteration samples uniformly without replacement
from the currently available states in that block, using at most the requested
batch size. States can be sampled again in later iterations. Their associated
weights contribute to transition estimates.

The regular stability condition uses the maximum relative change in accumulated,
normalized transition probabilities. After more than three iterations, the
threshold must be met for four consecutive checks, with at least one requested
batch of states available in the next block. A newly nonzero transition from a
previous zero estimate has infinite relative change.

The implementation also increments the stability counter after iteration 100,
regardless of the relative-change test; the next-block population requirement
still applies. Therefore 100 is not a hard iteration limit, and leaving a block
does not always certify numerical convergence. If no next-block states can be
found after more than 10 iterations, the calculation saves its partial transition
estimate and returns early. Inspect `Markov/runtime_log.txt` when interpreting
small or zero probabilities.

The collision block is regenerative: it transitions to the safest block with
probability one. With all eight transition rows observed, stationary probabilities
are solved by a constrained linear system. Otherwise missing rows become
self-loops and power iteration starts in the safest block. Values smaller than
1e-15 in absolute magnitude are set to zero in the linear-solve branch. Zero
estimates do not establish zero underlying collision risk.

`--seed` controls splitting and training (Python, NumPy and PyTorch). Monte Carlo
and Markov subprocesses currently do not receive a fixed seed. Repeated simulation
results can differ; this release does not provide repeated-seed confidence
intervals or claim exact stochastic reproduction.

## Outputs per vehicle

| File | Contents |
| --- | --- |
| `behavior_modeling/best.pth` | Best validation checkpoint |
| `behavior_modeling/final.pth` | Copy of the reloaded best checkpoint |
| `behavior_modeling/split_manifest.json` | File/trajectory IDs, temporal boundaries and sample counts |
| `behavior_modeling/calibration.json` | Residual calibration parameters |
| `behavior_modeling/test_metrics.json` | Independent test errors and continuous-model coverage |
| `behavior_modeling/training_summary.json` | Configuration, timing and best validation MAE |
| `benchmark/additional_stats.json` | Mean headway, squared acceleration, fuel-use proxy and sample counts |
| `benchmark/ttc_prob_benchmark_data.json` | Monte Carlo TTC **counts**, despite the historical filename |
| `benchmark/states_record.json` | State visit counts for Markov initialization |
| `Markov/accumulated_transition_counts.json` | Accumulated block-transition estimates |
| `Markov/steady_state_result.json` | Stationary TTC probabilities |
| `Markov/runtime_log.txt` | Block progress and stopping reasons |

`crash_rate` in the stationary output is collision-block occupancy, not collisions
per second. The first bucket is internally labeled `-inf-0`, and the last is
`8-inf`; the code uses an unbounded last bucket, not a finite TTC cap.
The historical `crash_log.txt` collision counter is not updated by the current
Monte Carlo loop; use the TTC count output for observed collision-block occupancy.

Headway uses `max(0, Spatial_Gap) / Speed_FAV` for positive following speed. Squared acceleration
uses the sampled action. Fuel use is a common hypothetical VT-Micro proxy, not
a vehicle-specific consumption measurement; its coefficients are in
`evaluation/MonteCarlo.py`. Rebirth/out-of-domain steps are excluded from these
driving metrics, and the retained sample counts are saved.

To export three numerical CSV tables after all eight runs:

```bash
python experiments/summarize_results.py --results_root results --output_dir experiments/summary
```

This writes `driving_metrics.csv`, `ttc_probabilities.csv` and `test_metrics.csv`,
preserving numerical precision. The export reads saved outputs; it does not
certify convergence or recompute the experiments. No plotting dependency is used.
