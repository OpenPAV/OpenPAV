"""Export eight-vehicle metrics, TTC probabilities and independent test errors as CSV."""
import argparse
import csv
import json
from pathlib import Path


TTC_LABELS = ['-inf-0', '0-0.25', '0.25-0.75', '0.75-1.5',
              '1.5-3', '3-5', '5-8', '8-inf']


def read_json(path):
    return json.loads(path.read_text())


def write_csv(path, rows):
    with path.open('w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--results_root', type=Path, default=Path('results'))
    parser.add_argument('--output_dir', type=Path, default=Path('experiments/summary'))
    args = parser.parse_args()
    vehicles = read_json(Path(__file__).with_name('vehicles.json'))
    driving, ttc, test = [], [], []
    for vehicle in vehicles:
        root = args.results_root / vehicle['run_name']
        model = vehicle['model']
        stats = read_json(root / 'benchmark/additional_stats.json')
        steady = read_json(root / 'Markov/steady_state_result.json')['steady_state']
        metrics = read_json(root / 'behavior_modeling/test_metrics.json')
        driving.append({'Model': model,
                        'Time Headway (s)': stats['avg_time_headway'],
                        'Acceleration Square (m^2/s^4)': stats['avg_acceleration_square'],
                        'Fuel-use Proxy (L/s)': stats['avg_fuel_consumption_rate_vtm']})
        ttc.append({'Model': model, **{key: steady[key] for key in TTC_LABELS}})
        test.append({'Model': model, **{key: metrics[key] for key in
                    ['samples', 'mae', 'rmse', 'calibrated_mae', 'calibrated_rmse']},
                    **{f'coverage_{level}': metrics.get('continuous_power_law_coverage', {}).get(level, '')
                       for level in ['0.5', '0.9', '0.95', '0.99']}})
    args.output_dir.mkdir(parents=True, exist_ok=True)
    for name, rows in [('driving_metrics.csv', driving), ('ttc_probabilities.csv', ttc),
                       ('test_metrics.csv', test)]:
        write_csv(args.output_dir / name, rows)
    print(f'Saved three CSV tables to {args.output_dir}')


if __name__ == '__main__':
    main()
